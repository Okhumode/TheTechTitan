import asyncio
import traceback
from better_proxy import Proxy
from pyrogram import Client
from pyrogram.errors import Unauthorized, UserDeactivated, AuthKeyUnregistered, FloodWait
from pyrogram.raw.functions.messages import RequestWebView
from bot.utils import logger
from bot.utils.scripts import run_catizen
from bot.exceptions import InvalidSession

class Tapper:
    def __init__(self, tg_client: Client, lock: asyncio.Lock):
        self.session_name = tg_client.name
        self.tg_client = tg_client
        self.user_id = 0
        self.lock = lock
        self.logged_in = False

    async def get_tg_web_data(self, proxy: str | None) -> str:
        if proxy:
            proxy = Proxy.from_str(proxy)
            proxy_dict = dict(
                scheme=proxy.protocol,
                hostname=proxy.host,
                port=proxy.port,
                username=proxy.login,
                password=proxy.password
            )
        else:
            proxy_dict = None

        self.tg_client.proxy = proxy_dict

        try:
            with_tg = True

            if not self.tg_client.is_connected:
                with_tg = False
                try:
                    await self.tg_client.connect()
                except (Unauthorized, UserDeactivated, AuthKeyUnregistered):
                    raise InvalidSession(self.session_name)

            while True:
                try:
                    peer = await self.tg_client.resolve_peer('catizenbot')
                    break
                except FloodWait as fl:
                    fls = fl.value

                    logger.warning(f"{self.session_name} | FloodWait {fl}")
                    logger.info(f"{self.session_name} | Sleep {fls}s")

                    await asyncio.sleep(fls + 3)

            web_view = await self.tg_client.invoke(RequestWebView(
                peer=peer,
                bot=peer,
                platform='android',
                from_bot_menu=False,
                url='https://tgsvr.catizen.ai/api/bot/tmas/gameapp/catizenbot/'
            ))

            auth_url = web_view.url

            tg_web_data = auth_url.split('tgWebAppData=', maxsplit=1)[1].split('&tgWebAppVersion', maxsplit=1)[0]
            self.user_id = (await self.tg_client.get_me()).id

            if with_tg is False:
                await self.tg_client.disconnect()

            return tg_web_data

        except InvalidSession as error:
            raise error

        except Exception as error:
            logger.error(f"{self.session_name} | Unknown error during Authorization: {error}")
            await asyncio.sleep(delay=3)

    async def login(self, tg_web_data: str) -> tuple[dict[str], str]:
        try:
            async with self.lock:
                if not self.logged_in:
                    cracker_first, cracker_second = run_catizen(tg_web_data=tg_web_data)
                    self.logged_in = True
                    logger.info(f"{self.session_name} | Successfully logged in.")
                else:
                    logger.info(f"{self.session_name} | Login already executed, skipping...")

            return cracker_first, cracker_second
        except Exception as error:
            traceback.print_exc()
            logger.error(f"{self.session_name} | Unknown error while glogging in: {error}")
            await asyncio.sleep(delay=3)
            raise InvalidSession(self.session_name)

    async def run(self, proxy: str | None) -> None:
        try:
            tg_web_data = await self.get_tg_web_data(proxy=proxy)
            await self.login(tg_web_data) 
        except InvalidSession:
            logger.error(f"{self.session_name} | Invalid Session")


async def run_tapper(tg_client: Client, proxy: str | None, lock: asyncio.Lock):
    try:
        await Tapper(tg_client=tg_client, lock=lock).run(proxy=proxy)
    except InvalidSession:
        logger.error(f"{tg_client.name} | Invalid Session")
