
# 🤡 Seek professional Help if you still mess this up 🤡

API_ID =27730401            # Not in quotes - Example: API_ID = 
API_HASH = ""       # in quotes "" - Example: API_HASH  = "5593d9e303eb47f367305cb7612696c3"

# delay between connections to accounts
ACC_DELAY = [3, 5]

# folder with sessions (do not change)
WORKDIR = "sessions/"

# Use proxy
USE_PROXY = False # True/False

PROXY_TYPE = "socks5"

# Full link to your Sessions folder
SESSIONS_PATH = "YOUR PATH TO SESSIONS"

# How many points per game
POINTS = [580, 600] #[min, max]

# Spend tickets
SPEND_TICKETS = True # True/False

# Sleep between games
SLEEP_GAME_TIME = [9,21] #[min,max]

# mini sleep
MINI_SLEEP = [3,7] #[min,max]

hello ='''

▀▀█▀▀ █▀▀█ █▀▄▀█ █▀▀█ ▀▀█▀▀ █▀▀█ ▒█▀▀█ █▀▀█ ▀▀█▀▀ 
░▒█░░ █░░█ █░▀░█ █▄▄█ ░░█░░ █░░█ ▒█▀▀▄ █░░█ ░░█░░ 
░▒█░░ ▀▀▀▀ ▀░░░▀ ▀░░▀ ░░▀░░ ▀▀▀▀ ▒█▄▄█ ▀▀▀▀ ░░▀░░
                                          
'''
